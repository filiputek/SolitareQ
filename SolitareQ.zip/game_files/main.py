from logics import *
from enum import Enum
import input_manager as in_man
import output_manager as out_man
import random
import codecs
COLUMN_COUNT=7
BACKWARDS_DEPTH=4
HELP_PATH="help/"
#return a full sorted deck of cards
def giveCardDeck():
    deck=[]
    for cardSuit in range(4):
        for figure in range(Figures.a.value, Figures.k.value+1):
            deck.append(Card(figure, Suits[SUIT_NUMS[cardSuit]]))
    return deck

#prepare all cards for the start of a game
def setGameTable(cardDeck):
    #nth column(indexing from 1) should have n-1 hidden and one revealed card on it
    columns=[]
    for col in range(COLUMN_COUNT):
        hiddenList=[]
        for c in range(col+1):
            hiddenList.append(cardDeck.pop())
        hiddenGroup=UnrevealedGroup(hiddenList)
        #empty columns have 14 as their topValue, so we can put kings on them
        columns.append(Column(hiddenGroup, Sequence(Figures.k.value+1, [])))
        columns[col].revealHidden()
    #prepare final piles
    finalPiles=[]
    for s in SUIT_NUMS:
        finalPiles.append(FinalStack(Suits[s]))
    #prepare a reserve pile
    reservePile=Pile(cardDeck)

    return GameState(finalPiles, reservePile, columns)

#execute a given command with given arguments
def executeCommand(gameState, command, arguments):
    feedback=""
    image=""
    if(command=="m"):
        gameState.updatePrev(BACKWARDS_DEPTH)
        gameState.moveCards(arguments)
        feedback="Successfully moved card(s)!"
        image = out_man.giveGameTableText(gameState)
    elif(command=="rf"):
        gameState.updatePrev(BACKWARDS_DEPTH)
        if(gameState.reservePile.flippedCount==gameState.reservePile.size):
            gameState.reservePile.unflipAll()
            feedback="All cards successfully unflipped!"
        else:
            gameState.reservePile.flipOne()
            feedback="One card successfully flipped!"
        image=out_man.giveGameTableText(gameState)
    elif(command=="back"):
        gameState.goBack()
        feedback="Move successfully undone!"
        image = out_man.giveGameTableText(gameState)
    elif(command=="show"):
        if(arguments["part"]=="c"):
            image = out_man.giveColumnsText(gameState.columns)
        elif(arguments["part"]=="rp"):
            image = out_man.givePileText(gameState.reservePile)
        elif (arguments["part"] == "f"):
            image = out_man.giveFinalStacksText(gameState.finalStacks)
        else:
            image = out_man.giveGameTableText(gameState)
    elif(command=="simplify"):
        if(arguments["active"]=="on"):
            out_man.setGraphicsMode("simple")
            feedback="Simple graphics mode on."
        elif(arguments["active"]=="off"):
            out_man.setGraphicsMode("normal")
            feedback="Simple graphics mode off."
    elif(command=="surrender"):
        if(gameState.surrender==surrenderStage.idle):
            gameState.surrender = surrenderStage.tried
            feedback="Type the same command again to confirm the end of the game."
        elif(gameState.surrender==surrenderStage.tried):
            gameState.surrender = surrenderStage.done
            feedback = "Game ended."
    elif(command=="help"):
        #you won't get files other than those in "help" folder
        #thanks to helpArgList in input_sanitizer.py
        helpFilePath=f"{HELP_PATH}{arguments['subject']}.txt"
        with codecs.open(helpFilePath, encoding='utf-8') as helpFile:
            feedback=helpFile.read()
    out_man.giveMessage(feedback)
    out_man.printImage(image)

if(__name__=="__main__"):
    #set graphics mode to default
    out_man.setGraphicsMode("normal")
    # print a splashscreen
    out_man.printImage(out_man.splashscreen)

    #major game loop - exists until the end of program
    while(True):
        #wait for user's action to start a new game
        out_man.giveMessage("Press enter to start a new game.")
        in_man.waitForAction()
        #create a deck of cards and a starting game table
        deck=giveCardDeck()
        random.shuffle(deck)
        gameState=setGameTable(deck)
        #print an image of game table and some info
        out_man.printImage(out_man.giveGameTableText(gameState))
        out_man.giveMessage("Need some help? Type \"help\" for more information. \nImages aren't showing how they should? Type \"simplify on\" for minimalist graphics!")

        #minior game loop - exists in time of one game session
        while gameState.surrender!=surrenderStage.done and not(gameState.checkForWin()):
            isValid, rest = in_man.readAndPrepareInput(gameState)
            if(gameState.surrender==surrenderStage.tried and (not(isValid) or rest[0]!="surrender")):
                gameState.surrender=surrenderStage.idle
                out_man.giveMessage("Surrendering cancelled.")
            if(isValid):
                command=rest[0]
                args=rest[1]
                executeCommand(gameState, command, args)
            else:
                feedback=rest
                out_man.giveMessage(feedback)

            if(gameState.checkForWin()):
                out_man.printImage(out_man.winImage)
