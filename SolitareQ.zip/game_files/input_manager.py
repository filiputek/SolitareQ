from logics import *
from input_sanitizer import *
import json

FORMATS_PATH = "command_formats.json"
FORMATS=json.loads(open(FORMATS_PATH).read())


def fillOptionalArguments(gameState, command, args):
    #fill optional arguments for commands
    if(command=="m"):
        for i in range(4):
            if(args["con1"]=="f"+SUIT_NUMS[i]):
                args["con1"]="f"+str(i+1)
            if(args["con2"]=="f"+SUIT_NUMS[i]):
                args["con2"]="f"+str(i+1)
        #fill quantity if necessary
        if(args["quantity"]=="-"):
            shouldFill= args["con1"][0]==args["con2"][0]=="c"
            if(shouldFill):
                con1=gameState.giveContainerByName(args["con1"])
                con2=gameState.giveContainerByName(args["con2"])
                upperCardValue=con2.visible.giveLowestCard().value
                potentialQuantity=upperCardValue-con1.visible.giveLowestCard().value
                if(1<=potentialQuantity<=con1.visible.size):
                    args["quantity"]=str(potentialQuantity)
                else:
                    args["quantity"]="0"

    elif(command=="rf"):
        pass
    elif(command=="show"):
        if(args["part"]=="-"):
            args["part"] ="all"
    elif(command=="simplify"):
        pass
    elif(command=="surrender"):
        pass
    elif(command=="help"):
        #gives universal help if no help type specified
        if(args["subject"]=="-"):
            args["subject"]="universal"

def readAndPrepareInput(gameState):
    #get input from user
    user_input=""
    #if input is empty, just ask for in one more time
    while(user_input==""):
        user_input=input().lower()

    #split input into a type of command and its arguments
    #if command doesn't exist, it gets name 'CommandNotFound' instead
    command=user_input.split()[0]
    if(command not in FORMATS.keys()):
        command="CommandNotFound"
    argValues=user_input.split()[1:]
    
    #get names of needed arguments from a .json file
    #and fill not given arguments with "-"
    #then add one excess element at the end of argNames
    #to easily detect excess of given arguments
    givenArgCount=len(argValues)
    argNames = FORMATS[command].copy()
    argValues+=["-"]*max(0, len(argNames)-givenArgCount)
    argNames.append("excess")
    #make a dict in form of argumentName:itsValue
    #and fill optional arguments with default values if necessary
    arguments=dict(zip(argNames, argValues))
    fillOptionalArguments(gameState, command, arguments)
    #check if given operation is doable.
    #if yes, return a read command type and its arguments
    #if not, return a message to be shown to user
    isValid, feedback =sanitizeInput(command, gameState, arguments)
    if(isValid):
        return(True, (command, arguments))
    else:
        if(command=="CommandNotFound"):
            feedback +="\nType \"help\" to see available commands."
        else:
            feedback +=f"\nType \"help\" or \"help {command}\" for more information."
        return(False, feedback)

# simply wait for pressing enter by user
# I did it in a separate function, because:
# 1. I want to do all input-managing in this file
# 2. I may want to expand this function
def waitForAction():
    input()