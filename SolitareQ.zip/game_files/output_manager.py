from logics import*
from enum import Enum
import re
import codecs
splashscreen=[]
winImage=[]
#prepare global variables needed to use certain graphics mode - either normal or simple
def setGraphicsMode(mode):
    # a height of one card
    global cardHeight
    # a width of one card
    global cardWidth
    # dict of suit symbols
    global suitSymbols
    #a splashscreen stored in form of a list of strings
    global splashscreenPath
    global splashscreen
    # card images stored in form of a dict of lists of strings
    global cardsArtPath
    global cardImages
    #an image and text displayed when the player wins
    global winImagePath
    global winImage
    #dict used to decorate ansi escape characters - coloring, underline, overline(not used, because not working in some places)
    global decorations

    normalDecorations = {"underline": "\x1b[4m", "overline": "\x1b[53m", "end": "\x1b[0m", "red": "\x1b[31m", "black": "\x1b[37m", "univ": "\x1b[32m"}
    cardWidth = 7
    splashscreenPath="ascii_graphics/splashscreen.txt"
    winImagePath="ascii_graphics/win_image.txt"
    if(mode=="normal"):
        cardsArtPath = "ascii_graphics/all_cards_normal.txt"
        cardHeight = 4
        suitSymbols = {Suits.c: "♣", Suits.d: "♦", Suits.h: "♥", Suits.s: "♠", Suits.u: "#"}
        cardImages = readCardsArt(cardsArtPath)
        decorations = normalDecorations
    elif(mode=="simple"):
        cardsArtPath = "ascii_graphics/all_cards_simple.txt"
        cardHeight = 2
        suitSymbols = {Suits.c: "B1", Suits.d: "C1", Suits.h: "C2", Suits.s: "B2", Suits.u: "##"}
        decorations={}
        for i in normalDecorations.keys():
            decorations[i]=""
    with codecs.open(splashscreenPath, encoding='utf-8') as f:
        splashscreen = f.read().split("\n")
    cardImages = readCardsArt(cardsArtPath)
    with codecs.open(winImagePath, encoding='utf-8') as f:
        winImage = f.read().split("\n")
#returns a text with removed ansi escape characters
#works only for graphics mode characters ending with m
#because I don't need other ones ¯\_(ツ)_/¯
def ansiStrip(text):
    return re.sub(r"\x1b[^m]*m", "", text)

# read ascii art of cards from a .txt file
# question marks substitute suit symbols in it
def readCardsArt(f):
    cardsImg=[[] for _ in range(Figures.k.value-Figures.a.value+3)]
    #cardsImg[0] is an art of empty card slot
    #Images from 1 to 13 are representing cards from ace to king
    #cardsImg[14] is a back of a card
    with codecs.open(f, encoding='utf-8') as cardsArt:
        lineIndex=0
        for line in cardsArt:
            if(lineIndex%(cardHeight+1)<cardHeight):
                cardsImg[lineIndex//(cardHeight+1)].append(line.strip())
            lineIndex+=1
    return cardsImg

#merge a few list of texts into one list side by size with given separators between them
def mergeTextHorizontally(subtexts, separator=""):
    text=[]
    maxSubtextSize=max(map(lambda x: len(x), subtexts))
    for i in subtexts:
        subtexts=list(map(lambda x: x+[" "*(cardWidth)]*(maxSubtextSize-len(x)), subtexts))
    for i in range(maxSubtextSize):
        text.append(separator.join(list(map(lambda x: x[i], subtexts))))
    return text

#return a list of strings showing a given nuber of top rows of a single card
#if topRowsCount is equal to -1, it prints the entire card
def giveTopOfCardText(card, topRowsCount=-1):
    if(topRowsCount==-1):
        topRowsCount=cardHeight
    text=[]
    for row in range(topRowsCount):
        text.append(decorations[Colors[card.suit.name].value]+ cardImages[card.value][row] +decorations["end"])
        text[-1]=text[-1].replace("?", suitSymbols[card.suit][0])
        if(len(suitSymbols[card.suit])>1):
            text[-1] = text[-1].replace("!", suitSymbols[card.suit][1])
    text[topRowsCount-1]=decorations["underline"]+text[topRowsCount-1]+decorations["end"]
    return text

#return a list of strings showing a given column of cards
def giveColumnText(col):
    text=[]
    for row in col.hidden.cards:
        text+=giveTopOfCardText(Card(14, Suits.u), 1)
    for row in zip(reversed(range(col.visible.topValue-col.visible.size+1, col.visible.topValue+1)), col.visible.cardSuits):
        text+=giveTopOfCardText(Card(row[0], row[1]), 1)

    #if there are no visible cards
    #then there are no cards here at all
    #so put an empty slot sign
    if(col.visible.size==0):
        for row in giveTopOfCardText(Card(0, Suits.u)):
            text.append(row)
    else:
        text.pop(-1)
        text+=giveTopOfCardText(col.visible.giveLowestCard())
    return text

#return a list of strings showing an image of given reserve pile
def givePileText(pile):
    if(pile.flippedCount==0):
        visibleText=giveTopOfCardText(Card(0, Suits.u))
    else:
        visibleText=giveTopOfCardText(pile.giveLatestVisible())

    if(pile.size-pile.flippedCount==0):
        hiddenText = giveTopOfCardText(Card(0, Suits.u))
    else:
        hiddenText = giveTopOfCardText(Card(14, Suits.u))
    return mergeTextHorizontally([visibleText, hiddenText], separator=" ")

#give an image of final stacks of cards
def giveFinalStacksText(finalStacks):
    stacksTexts=[]
    for stack in finalStacks[:4]:
        stacksTexts.append(giveTopOfCardText(stack.giveTopCard()))
    return mergeTextHorizontally(stacksTexts, separator=" ")

def giveColumnsText(columns):
    text = mergeTextHorizontally(list(map(lambda x: giveColumnText(x), columns)), separator=" ")
    return text
#return a representation of entire game table in list of strings
def giveGameTableText(gt):
    text=[]
    text+=mergeTextHorizontally([giveFinalStacksText(gt.finalStacks), givePileText(gt.reservePile)], separator=(" "*4+"|"+" "*4))
    text+=["-"*len(ansiStrip(text[-1]))]
    text+=giveColumnsText(gt.columns)
    return text

#print a given list of strings
def printImage(txt):
    if(len(txt)==0):
        return
    for i in txt:
        print(i)

#simply print a message
def giveMessage(message):
    if (len(message) == 0):
        return
    print(message)

if(__name__=="__main__"):
    setGraphicsMode("normal")