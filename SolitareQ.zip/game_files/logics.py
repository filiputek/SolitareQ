#module containing definitions of classes

from enum import Enum
import random
import copy

#Enum that helps to differentiate card suits
#helps to convert letter symbols of suits to their numbers
class Suits(Enum):
    #Clubs
    c=0
    #Diamonds
    d=1
    #Hearts
    h=2
    #Spades
    s=3
    #universal suit(anything can be put on it)
    u=4
#a tuple that helps to convert numbers of card suits to their letter symbols
SUIT_NUMS = ("c", "d", "h", "s", "u")

#Enum saying what color is a card suit of
class Colors(Enum):
    #Diamonds and hearts - Red
    d="red"
    h="red"
    #Clubs and spades - black
    c="black"
    s="black"
    #universal color(anything can be put on it)
    u="univ"
    
#Enum describing card figures
class Figures(Enum):
    #Ace, lower than 2
    a=1
    #Jack, higher than 10
    j=11
    #Queen, higher than Jack
    q=12
    #King, higher that Queen
    k=13

#enum describing states of surrendering
class surrenderStage(Enum):
    #player didn't try to surrender
    idle=0
    #player wants to surrender, but didn't confirm their wish
    tried=1
    #player definitely ends the game
    done=2
#A single game card
class Card:
    def __init__(self, value, suit):
        self.value=value
        self.suit=suit
    def turnToSequence(self):
        return Sequence(self.value, [self.suit])

#A sequence of correctly placed revealed cards
#laying in the same column
class Sequence:
    def __init__(self, topValue, cardSuits):
        self.topValue=topValue
        self.size=len(cardSuits)
        self.cardSuits=cardSuits

    #takes off a certain number of cards from the sequence
    def takeOff(self, quantity):
        self.size-=quantity
        self.cardSuits=self.cardSuits[:self.size]
        if(self.size==0):
            self.topValue=Figures.k.value+1
    #add a correct sequence to the bottom
    #(assumes that operation is done correctly)
    def putDown(self, addedSequence):
        if(self.size==0):
            self.topValue=Figures.k.value
        self.size+=addedSequence.size
        self.cardSuits+=addedSequence.cardSuits

    #returns N cards at the bottom of the sequence
    #in form of another, smaller sequence
    def giveNLowestCards(self, n):
        partialTopValue=self.topValue-self.size+n
        return Sequence(partialTopValue, self.cardSuits[-n:])
    
    #returns the lowest card in a sequence
    #in from of class Card instance
    def giveLowestCard(self):
        if(self.size==0):
            return Card(14, Suits.u)
        return Card(self.topValue-self.size+1, self.cardSuits[-1])

    #returns the highest card in a sequence
    #in from of class Card instance
    def giveHighestCard(self):
        if(self.size==0):
            return Card(14, Suits.u)
        return Card(self.topValue, self.cardSuits[0])

#a group of unrevealed cards laying in one column
class UnrevealedGroup:
    def __init__(self, cards):
        self.cards=cards
        self.size=len(cards)
    #delete the bottom card
    def takeOneOff(self):
        self.cards.pop(-1)
        self.size-=1
#A single column used to put cards on it
class Column:
    def __init__(self, hidden, visible):
        self.hidden=hidden
        self.visible=visible

    #reveal one card
    def revealHidden(self):
        self.visible=self.hidden.cards[-1].turnToSequence()
        self.hidden.takeOneOff()

    #take away given quantity of cards
    def takeOff(self, quantity):
        self.visible.takeOff(quantity)
        if(self.visible.size==0 and self.hidden.size>0):
            self.revealHidden()

#Pile used for reserve cards
class Pile:
    def __init__(self, cards):
        self.size=len(cards)
        self.cards=cards
        self.flippedCount=0
        
    #take one card from the hidden part of pile
    #and put it on the visible part
    def flipOne(self):
        self.flippedCount+=1

    #when all cards are flipped,  make them all hidden again
    def unflipAll(self):
        random.shuffle(self.cards)
        self.flippedCount=0

    #give a top card
    def giveLatestVisible(self):
        topFlippedIndex=self.flippedCount-1
        return self.cards[topFlippedIndex]
    
    #take the latest flipped card away
    def takeLatestVisible(self):
        topFlippedIndex=self.flippedCount-1
        self.cards.pop(topFlippedIndex)
        self.size-=1
        self.flippedCount-=1


#stacks to put cards of one color on them
#in the increasing order
class FinalStack:
    def __init__(self, suit):
        self.stackSize=0
        self.suit=suit
    #adds a card to a pile
    def putACard(self):
        self.stackSize+=1

    #takes a card from a pile away
    def takeACard(self):
        self.stackSize-=1

    #return an object of card at the top
    def giveTopCard(self):
        return Card(self.stackSize, self.suit)

#a class containing info about state of the game
class GameState:
    def __init__(self, finalStacks, reservePile, columns, prev=None):
        self.finalStacks=finalStacks
        self.reservePile=reservePile
        self.columns=columns
        #tells if player wants to end the game session
        self.surrender = surrenderStage.idle
        #contains a previous game state or None if we don't want to have it
        self.prev=prev
    #moves n cards from column a to b
    def moveSequence(self, n, col1, col2):
        toMove=col1.visible.giveNLowestCards(n)
        col1.takeOff(n)
        col2.visible.putDown(toMove)

    #moves a card from a chosen column to a final stack
    def moveFromColumnToFinalStack(self, col):
        toMoveCard=Card(col.visible.topValue-col.visible.size+1, col.visible.cardSuits[-1])
        col.takeOff(1)
        self.finalStacks[toMoveCard.suit.value].putACard()
    
    #moves a card from the reserve pile to a chosen column
    def moveFromPileToColumn(self, col):
        toMoveCard=self.reservePile.giveLatestVisible()
        toMoveSeq=toMoveCard.turnToSequence()
        self.reservePile.takeLatestVisible()
        col.visible.putDown(toMoveSeq)

    #move a card from the reserve pile to a final stack
    def moveFromPileToFinalStack(self):
        toMoveCard=self.reservePile.giveLatestVisible()
        self.reservePile.takeLatestVisible()
        self.finalStacks[toMoveCard.suit.value].putACard()

    def moveFromFinalStackToColumn(self, suit, col):
        toMoveSeq=Sequence(self.finalStacks[suit.value].stackSize, [suit])
        self.finalStacks[suit.value].takeACard()
        col.visible.putDown(toMoveSeq)

    #returns an object of container depending on its name
    #for example: c1 returns self.columns[1].
    #if container is a final stack and a suit is not given
    #then returned final pile is  self.finalStacks[4] - unused stack with suit "u"
    def giveContainerByName(self, containerName):
        if(containerName[0]=="c"):
            if(containerName[1:] in list(map(lambda x: str(x), range(1,len(self.columns)+1)))):
                return self.columns[int(containerName[1:])-1]
            else:
                return Column(UnrevealedGroup([]), Sequence(0, []))
        if(containerName[0]=="f"):
            if(len(containerName)==1):
                return self.finalStacks[4]
            return self.finalStacks[int(containerName[1:])-1]
        else:
            return self.reservePile

    #moves cards from one container to another
    def moveCards(self, args):
        #assign command's arguments and their types
        #to variables
        con1=self.giveContainerByName(args["con1"])
        con2=self.giveContainerByName(args["con2"])
        conTypes=(type(con1), type(con2))
        quantity=args["quantity"]

        #call a right function depending on types of containers
        #could use match statement, but it doesn't support
        #multiple assignment
        if(conTypes==(Column, Column)):
            self.moveSequence(int(quantity), con1, con2)
        elif(conTypes==(Column, FinalStack)):
            self.moveFromColumnToFinalStack(con1)
        elif(conTypes==(Pile, Column)):
            self.moveFromPileToColumn(con2)
        elif(conTypes==(Pile, FinalStack)):
            self.moveFromPileToFinalStack()
        elif(conTypes==(FinalStack, Column)):
            self.moveFromFinalStackToColumn(con1.suit, con2)

    #checks for the winning condition(all cards are on final stacks)
    def checkForWin(self):
        for fs in range(4):
            if(self.finalStacks[fs].stackSize!=13):
                return False
        return True

    #a recursive function deleting the oldest saved game state
    def deleteOldestState(self):
        if(self.prev!=None and self.prev.prev==None):
            self.prev=None
        else:
            self.prev.deleteOldestState()

    #function called before changing anything in game state
    #it updates the previous state of game
    #and deletes the oldest save if it can
    def updatePrev(self, maxBackDepth):
        self.prev = copy.deepcopy(self)
        g=self
        depth=1
        while(g.prev!=None and depth<=maxBackDepth):
            g=g.prev
            depth+=1

        if(depth>maxBackDepth):
            self.deleteOldestState()


    #go back to the previous state
    def goBack(self):
        self.__dict__=self.prev.__dict__