#module used to help with determining is given action possible or not

from logics import*
CONTAINERS=["c1", "c2", "c3", "c4", "c5", "c6", "c7", "f1", "f2", "f3", "f4", "f", "rp"]
SHOW_OPTIONS=["all", "c", "rp", "f"]
HELP_ARG_LIST=["rules", "universal", "m", "rf", "show", "simplify", "surrender", "help"]
SIMPLIFY_ARG_LIST=["on", "off"]
#says is putting one card under other one in one game column legal or not
def isStackingPossible(upperCard, bottomCard):
    return (Colors[str(upperCard.suit.name)]!=Colors[str(bottomCard.suit.name)] and upperCard.value==bottomCard.value+1)
    
#dict telling what to write to the screen in every reason why not to execute the command given by user.
#first element of tuple is a lambda function checking correctness of the command
#the second one is a message to write on the screen in that case.
#every lambda gets as arguments a current game state and arguments used on the command.
exceptions={
"m":[
    #last element of every  tuple is its explanation itself.
    (lambda gs, args: not(args["con1"][0]=="c" and args["con2"][0]=="c") and args["quantity"]!="-", "Invalid usage: third argument only available when both containers ale columns."),
    
    (lambda gs, args: "excess" in args.keys(), "Invalid usage: too many arguments given."),

    (lambda gs, args: args["con2"]=="-", "Invalid usage: too few arguments given."),
    
    (lambda gs, args: args["con1"] not in CONTAINERS or args["con1"]=="f" or args["con2"] not in CONTAINERS, "Invalid usage: given container(s) does not exist."),
    
    (lambda gs, args: args["con2"]=="rp", "Invalid usage: cannot move a card to the reserve pile."),
    
    (lambda gs, args: ord(max(str(args["quantity"])))>ord('9') and ord(min(str(args["quantity"])))<ord('0'), "Invalid usage: given quantity should be a natural number"),
    
    (lambda gs, args: args["con1"]=="rp" and gs.reservePile.flippedCount==0, "Action not possible: no revealed cards on reserve pile."),
    
    (lambda gs, args: args["con1"][0]=="f" and gs.giveContainerByName(args["con1"]).stackSize<1, "Action not possible: chosen final pile is empty."),

    (lambda gs, args: args["quantity"]!="-" and gs.giveContainerByName(args["con1"]).visible.size<int(args["quantity"]), "Action not possible: not enough visible cards on the column."),

    (lambda gs, args: args["con1"][0]=="c" and gs.giveContainerByName(args["con1"]).visible.size<1, "Action not possible: not enough visible cards on the column."),
    
    (lambda gs, args: args["con2"][0]=="c" and gs.giveContainerByName(args["con2"]).visible.size==0 and (
    (args["con1"][0]=="c" and gs.giveContainerByName(args["con1"]).visible.topValue!=Figures.k.value)
    or (args["con1"][0]=="f" and gs.giveContainerByName(args["con1"]).stackSize!=Figures.k.value)
    or (args["con1"]=="rp" and gs.reservePile.giveLatestVisible().value!=Figures.k.value)),
     "Action not possible: only kings(K) can be placed on empty columns"),
    
    (lambda gs, args: args["con1"][0]=="c" and args["con2"][0]=="f" and len(args["con2"])>1 and gs.giveContainerByName(args["con1"]).visible.cardSuits[-1].value!=int(args["con2"][1:])-1,
     "Action not possible: chosen final pile's suit and a card's suit don't match"),
    
    (lambda gs, args: args["con1"]=="rp" and args["con2"][0]=="f" and len(args["con2"])>1 and gs.reservePile.giveLatestVisible().suit.value!=int(args["con2"][1:])-1,
     "Action not possible: chosen final pile's suit and a card's suit don't match"),
    
    (lambda gs, args: args["con1"][0]=="f" and args["con2"][0]=="f", "Action not possible: chosen final pile's suit and a card's suit don't match"),

    (lambda gs, args: args["con1"][0]=="c" and args["con2"][0]=="f" and gs.giveContainerByName(args["con1"]).visible.giveLowestCard().value-1!=
     gs.finalStacks[gs.giveContainerByName(args["con1"]).visible.giveLowestCard().suit.value].stackSize,
     "Action not possible: given card cannot be put in this final stack."),

    (lambda gs, args: args["con1"]=="rp" and  args["con2"][0]=="f" and gs.giveContainerByName(args["con1"]).giveLatestVisible().value-1!=
     gs.finalStacks[gs.giveContainerByName(args["con1"]).giveLatestVisible().suit.value].stackSize,
     "Action not possible: given card cannot be put in this final stack."),
    
    (lambda gs, args: args["con1"]=="rp" and args["con2"][0]=="c" and
     not(isStackingPossible(gs.giveContainerByName(args["con2"]).visible.giveLowestCard(), gs.reservePile.giveLatestVisible())),
     "Action not possible: given cards cannot be put in one column."),
    
    (lambda gs, args: args["con1"][0]=="f" and args["con2"][0]=="c" and
     not(isStackingPossible(gs.giveContainerByName(args["con2"]).visible.giveLowestCard(), gs.giveContainerByName(args["con1"]).giveTopCard())),
     "Action not possible: given cards cannot be put in one column."),

    (lambda gs, args: args["quantity"]!="-" and
     not(isStackingPossible(gs.giveContainerByName(args["con2"]).visible.giveLowestCard(),
                            gs.giveContainerByName(args["con1"]).visible.giveNLowestCards(int(args["quantity"])).giveHighestCard())),
     "Action not possible: given cards/sequences cannot be put in one column.")
],
"rf":[
    (lambda gs, args: "excess" in args.keys(), "Invalid usage: too many arguments given."),
    (lambda gs, args: gs.reservePile.size==0, "Action not possible: no cards left on the reserve pile.")
],
"show":[
    (lambda gs, args: "excess" in args.keys(), "Invalid usage: too many arguments given."),
    (lambda gs, args: args["part"] not in SHOW_OPTIONS, "Invalid usage: argument has an incorrect value")
],
"back":[
    (lambda gs, args: "excess" in args.keys(), "Invalid usage: too many arguments given."),
    (lambda gs, args: gs.prev==None, "Action not possible: cannot go back to the previous game state.")
],
"help":[
    (lambda gs, args: "excess" in args.keys(), "Invalid usage: too many arguments given."),
    (lambda gs, args: args["subject"] not in HELP_ARG_LIST, "Invalid usage: argument has an incorrect value")
],
"simplify":[
    (lambda gs, args: args["active"]=="-", "Invalid usage: too few arguments given."),
    (lambda gs, args: "excess" in args.keys(), "Invalid usage: too many arguments given."),
    (lambda gs, args: args["active"] not in SIMPLIFY_ARG_LIST, "Invalid usage: argument has an incorrect value")
],
"surrender":[
    (lambda gs, args: "excess" in args.keys(), "Invalid usage: too many arguments given.")
],
"CommandNotFound":[
    (lambda gs, args: True, "Command not recognized."),
]
}

#check is a certain command possible to execute in a given game state with given arguments
#if it is, return
def sanitizeInput(command, gameState, commandArguments):
    for exception in exceptions[command]:
        if (exception[0](gameState, commandArguments)):
            return (False, exception[1])
    return (True, "")
